package cn.newtouch.framework.event;

public interface ReloadEvent {
	
	void change();

}
