$(function() {
	$("#form1").ligerForm();
	$("#layout1").ligerLayout({
		leftWidth : 200
	});
});