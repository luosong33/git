package cn.newtouch.framework.cache;

import java.util.Set;

public class RedisManager {

	public void init() {
		// TODO Auto-generated method stub
		
	}

	public byte[] get(byte[] key) {
		// TODO Auto-generated method stub
		return null;
	}

	public void set(byte[] key, byte[] value) {
		// TODO Auto-generated method stub
		
	}

	public void set(byte[] key, byte[] value, int expire) {
		// TODO Auto-generated method stub
		
	}

	public void del(byte[] key) {
		// TODO Auto-generated method stub
		
	}

	public Set<byte[]> keys(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public String dbSize() {
		// TODO Auto-generated method stub
		return null;
	}

	public int getExpire() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void flushDB() {
		// TODO Auto-generated method stub
		
	}

}
